En estas carpetas se encuentran los documentos y los programas necesarios para generar las combinatorias necesarias para los diferentes modelados de "machine learning"

La carpeta de "reports/" contiene todos los reportes resultantes del programa ocupado para entrenar al algoritmo. Estan separados por el tamaño del Corpus

La carpeta "Codes/" contiene los programas usados junto con instrucciones para usarlos

La carpeta "data-sets/" contiene los datos necesarios para que los programas funcionen

