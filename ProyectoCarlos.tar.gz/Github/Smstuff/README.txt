En estas carpetas se encuentran los documentos y los programas necesarios para generar las combinatorias necesarias para los diferentes modelados de "machine learning"

En la carpeta de "Results/", se encuentran las carpetas "models/" (para almacenar los modelos) y "reports/". Esta última está dividida por el tamaño de corpus usado y el número de parámetros usados.

La carpeta "Codes/" contiene los programas usados junto con instrucciones para usarlos

La carpeta "data-sets/" contiene los datos necesarios para que los programas funcionen

