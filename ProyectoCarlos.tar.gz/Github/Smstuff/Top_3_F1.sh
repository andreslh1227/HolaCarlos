QUICKHOME=$PWD

cd $1

grep "F1" * > Scorefile.txt
mv Scorefile.txt $QUICKHOME

cd $QUICKHOME

python top.py 