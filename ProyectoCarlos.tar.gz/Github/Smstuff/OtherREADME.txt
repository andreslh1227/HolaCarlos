Los códigos presentados aquí generan las combinaciones de líneas de comando para correr una serie de procesos de "machine learning" con diferentes parámetros

Comb2.py  y Comb3.py requieren el parámetro de "--Corpus" el cuál puede ser "Modified" o "Base". Estos archivos generan las listas de comandos en otro archivo, el cual puede ser ejecutado con "sh"

Mod-tr es la versión modificada por del programa proporcionado. (Los parámetros son los mismos que el programa original, pero con un parámetro nuevo "--funs", el cual se debe repetir para cada función que se desee usar)

Top_3_F1.sh es un script que toma la dirección de los reportes que se quieren evaluar e imprime una lista con los 3 scores más altos y las combinatorias usadas para ello