with open("Scorefile.txt") as chivo:
	vals=[]
	for line in chivo.realines():
		line=line.strip('\n')
		line=line.split(":Flat F1: ")
		vals.append((line[0], line[1]))
		vals=sorted(vals, key=lambda x: x[1], reverse=True)

	for nm, vl in vals[:4]:
		print nm, vl +'\n'