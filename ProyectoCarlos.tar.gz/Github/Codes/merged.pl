
print"Cual es el archivo de output?";
$outt=(<STDIN>);
print"Cuantos docs?";
$n=300;
$nn=100;
@docList=glob('*');
@a=@docList;
 my @items;
  for ( 1 .. $n )
  {
    push @items, splice @a, rand @a, 1;
  }

  for ( 1 .. $nn )
  {
    push @items2, splice @a, rand @a, 1;
  }


for (my $i=0; $i < scalar @item; $i++){ #con esto y con el de abajo guardo los que se repiten además los quito de mis vectores
        if ($item[$i] eq "merged.pl"){
        splice @item, $i, 1;
}
}


open(OUTPUT, ">".$outt);
foreach $filename(@items){
open(INPUT, $filename);
print OUTPUT <INPUT>;
print OUTPUT "\n";
close (INPUT);
}

close(OUTPUT);

open(OUTPUT, ">trainig");
foreach $filename(@items2){
open(INPUT, $filename);
print OUTPUT <INPUT>;
print OUTPUT "\n";
close (INPUT);
}
close(OUTPUT);



