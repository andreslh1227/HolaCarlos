with open("Scorefile.txt") as chivo:
	vals=[]
	for line in chivo.readlines():
		snt=line.strip('\n')
		snt=snt.split(":Flat F1: ")
		vals.append((snt[0], snt[1]))
		vals=sorted(vals, key=lambda x: x[1], reverse=True)

	for nm, vl in vals[:3]:
		print (nm + ':\t' + vl +'\n')
