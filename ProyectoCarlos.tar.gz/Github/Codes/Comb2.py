from optparse import OptionParser

parser=OptionParser()
parser.add_option("--Corpus", dest="corto", choices=("Modified", "Base", "Final"), default="Base")

(options, args) = parser.parser_args()


if options.corpus =="Modified":
	train="100_training.txt"
	test="50_testing.txt"

else if options.corpus =="Base":
        train = "training-data-set-70.txt"
        test = "test-data-set-30.txt"
else:
        train="300_training.txt"
        test="100_testing.txt"


Funlist=["HasDash", "HasPM", "HasSlash", "NumInE", "NumInB", "NumInM", "UpInB", "UpInM", "UpInE", "BetweenPar", "AllCaps", "LowAtE"]

othfun=[[Funlist[x],Funlist[y]] for x in range(len(Funlist)) for y in range(x,len(Funlist)) if x!=y]

for fun in othfun:
        print("python3 Moded_training_val.py --inputPath data-sets/ --trainingFile " + train + " --testFile "+ test +" --outputPath ./ --funs "+" --funs ".join(fun))
